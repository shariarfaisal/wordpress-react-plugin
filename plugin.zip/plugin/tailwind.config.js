module.exports = {
  content: ["./src/**/*.php", "./src/**/*.js"],
  plugins: [require("@tailwindcss/typography")],
};
