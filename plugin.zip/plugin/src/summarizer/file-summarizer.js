const FileSummarizer = () => {
  return <div className={`summarizer summarizer-file`}></div>;
};

export default FileSummarizer;
