export const TextSummarizer = () => {
  return <div className={`summarizer summarizer-text`}></div>;
};
